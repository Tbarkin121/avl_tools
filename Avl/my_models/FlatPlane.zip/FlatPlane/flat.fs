 ---------------------------------------------------------------
 Surface and Strip Forces by surface

  Sref =  1.0000       Cref =  1.0000       Bref =  1.0000    
  Xref = 0.50000       Yref = 0.50000       Zref =  0.0000    

  Surface # 1     wing                                    
     # Chordwise =  2   # Spanwise =  2     First strip =  1
     Surface area Ssurf =    1.000000     Ave. chord Cave =    1.000000

 Forces referred to Sref, Cref, Bref about Xref, Yref, Zref
 Standard axis orientation,  X fwd, Z down         
     CLsurf  =   0.18132     Clsurf  =   0.09062
     CYsurf  =   0.00000     Cmsurf  =   0.05343
     CDsurf  =   0.00700     Cnsurf  =   0.00442
     CDisurf =   0.00700     CDvsurf =   0.00000

 Forces referred to Ssurf, Cave 
     CLsurf  =   0.18132     CDsurf  =   0.00700

 Strip Forces referred to Strip Area, Chord
    j     Xle      Yle      Zle      Chord    Area     c_cl     ai     cl_norm    cl       cd       cdv    cm_c/4     cm_LE   C.P.x/c
     1   0.0000  -0.2500   0.0000   1.0000   0.5000   0.1812   0.0772   0.1813   0.1813   0.0070   0.0000   0.0081  -0.0372    0.205
     2   0.0000   0.2500   0.0000   1.0000   0.5000   0.1812   0.0772   0.1813   0.1813   0.0070   0.0000   0.0081  -0.0372    0.205
 ---------------------------------------------------------------
